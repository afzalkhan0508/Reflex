def TestState(State):
    pass


def test_compile_state():
    # TODO: Implement test for compile_state function.
    pass
