"""Media component tests."""
