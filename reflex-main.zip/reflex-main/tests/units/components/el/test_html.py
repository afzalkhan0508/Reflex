from reflex.components.el.constants.html import ATTR_TO_ELEMENTS, ELEMENTS


def test_html_constants():
    assert ELEMENTS
    assert ATTR_TO_ELEMENTS
