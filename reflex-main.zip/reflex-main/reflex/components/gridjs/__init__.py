"""Grid components."""

from .datatable import DataTable

data_table = DataTable.create
