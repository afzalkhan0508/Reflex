export default {
  plugins: {
    "postcss-import": {},
    autoprefixer: {},
  },
};
