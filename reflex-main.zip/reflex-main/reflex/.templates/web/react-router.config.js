export default {
  future: {
    unstable_optimizeDeps: true,
  },
  ssr: false,
};
